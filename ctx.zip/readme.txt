
Create ctx file directory
and copy ctx to system path

mkdir ~/.config/ctx
touch ~/.config/ctx/ctx.txt
cp ctx ~/bin


